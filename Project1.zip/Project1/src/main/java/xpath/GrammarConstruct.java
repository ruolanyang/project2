package xpath;

import static express.BinaryFt.compFromString;
import static express.CompoundFt.conjFromString;

import express.*;
import grammar.XpathGrammarBaseVisitor;
import grammar.XpathGrammarParser;




public class GrammarConstruct extends XpathGrammarBaseVisitor<Grammar> {

    @Override
    public Grammar visitAp(XpathGrammarParser.ApContext ctx) {
        String docName = ctx.docName().fileName().getText();
        Grammar.PathOp op = Grammar.opFromString(ctx.pathOp().getText());
        Grammar rp = visit(ctx.rp());
        return new AbsolutePath(docName.substring(1, docName.length()-1), op, rp);
    }

    @Override
    public Grammar visitUnaryRp3(XpathGrammarParser.UnaryRp3Context ctx) {
        return new UnaryRp(UnaryRp.Type.Text, "text()");
    }

    @Override
    public Grammar visitBinaryRp1(XpathGrammarParser.BinaryRp1Context ctx) {
        Grammar leftRp = visit(ctx.rp(0));
        BinaryRp.Op op = BinaryRp.opFromString(ctx.pathOp().getText());
        Grammar rightRp = visit(ctx.rp(1));
        return new BinaryRp(leftRp, rightRp, op);
    }

    @Override
    public Grammar visitUnaryRp4(XpathGrammarParser.UnaryRp4Context ctx) {
        return new UnaryRp(UnaryRp.Type.Star, "*");
    }

    @Override
    public Grammar visitParaRp(XpathGrammarParser.ParaRpContext ctx) {
        Grammar rp = visit(ctx.rp());
        return new ParaRp(rp);
    }

    @Override
    public Grammar visitBinaryRp2(XpathGrammarParser.BinaryRp2Context ctx) {
        Grammar leftRp = visit(ctx.rp(0));
        BinaryRp.Op op = BinaryRp.opFromString(ctx.COMMA().getText());
        Grammar rightRp = visit(ctx.rp(1));
        return new BinaryRp(leftRp, rightRp, op);
    }

    @Override
    public Grammar visitUnaryRp1(XpathGrammarParser.UnaryRp1Context ctx) {
        return new UnaryRp(UnaryRp.Type.Tag, ctx.tagName().getText());
    }

    @Override
    public Grammar visitUnaryRp2(XpathGrammarParser.UnaryRp2Context ctx) {
        return new UnaryRp(UnaryRp.Type.Att, ctx.attName().ID().getText());
    }

    @Override
    public Grammar visitFilterRp(XpathGrammarParser.FilterRpContext ctx) {
        Grammar rp = visit(ctx.rp());
        Grammar ft = visit(ctx.filter());
        return new FilterRp(rp, ft);
    }

    @Override
    public Grammar visitUnaryRp5(XpathGrammarParser.UnaryRp5Context ctx) {
        return new UnaryRp(UnaryRp.Type.Self, ".");
    }

    @Override
    public Grammar visitUnaryRp6(XpathGrammarParser.UnaryRp6Context ctx) {
        return new UnaryRp(UnaryRp.Type.Pent, "..");
    }

    @Override
    public Grammar visitBinaryFt1(XpathGrammarParser.BinaryFt1Context ctx) {
        Grammar rpLeft = visit(ctx.rp(0));
        Grammar rpRight = visit(ctx.rp(1));
        BinaryFt.Comparator comp = compFromString(ctx.compOp().getText());
        return new BinaryFt(rpLeft, rpRight, comp);
    }

    @Override
    public Grammar visitBinaryFt2(XpathGrammarParser.BinaryFt2Context ctx) {
        Grammar rp = visit(ctx.rp());
        String stringConst = ctx.stringCondition().STRING().getText();
        return new BinaryConstantFt(rp, stringConst.substring(1, stringConst.length()-1));
    }

    @Override
    public Grammar visitParaFt(XpathGrammarParser.ParaFtContext ctx) {
        Grammar ft = visit(ctx.filter());
        return new ParaFt(ft);
    }

    @Override
    public Grammar visitNegFt(XpathGrammarParser.NegFtContext ctx) {
        Grammar ft = visit(ctx.filter());
        return new NegFt(ft);
    }

    @Override
    public Grammar visitCompoundFt(XpathGrammarParser.CompoundFtContext ctx) {
        Grammar ft1 = visit(ctx.filter(0));
        Grammar ft2 = visit(ctx.filter(1));
        CompoundFt.CONJ conj = conjFromString(ctx.CONJ().getText());
        return new CompoundFt(ft1, ft2, conj);
    }

    @Override
    public Grammar visitUnaryFt(XpathGrammarParser.UnaryFtContext ctx) {
        Grammar rp = visit(ctx.rp());
        return new UnaryFt(rp);
    }
}
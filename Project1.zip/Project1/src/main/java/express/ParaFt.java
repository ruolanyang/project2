package express;

import org.w3c.dom.Node;

import java.util.List;
import java.util.Objects;

public class ParaFt implements Grammar {

    final private Grammar ft;

    public ParaFt(Grammar ft) {
        Objects.requireNonNull(ft, "filter is null!");

        this.ft = ft;
    }

    @Override
    public List<Node> evaluate(List<Node> inputNodes) throws Exception {
        return this.ft.evaluate(inputNodes);
    }

    @Override
    public ExpressionKind getExpressionKind() {
        return ExpressionKind.ParaFt;
    }
}

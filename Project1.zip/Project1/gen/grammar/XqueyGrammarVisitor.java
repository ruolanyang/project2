// Generated from /Users/yiling/Desktop/2024 winter/232B/Project1/src/main/java/grammar/XqueyGrammar.g4 by ANTLR 4.13.1
package grammar;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link XqueyGrammarParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface XqueyGrammarVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by the {@code RpXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRpXq(XqueyGrammarParser.RpXqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code StringXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringXq(XqueyGrammarParser.StringXqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ParaXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParaXq(XqueyGrammarParser.ParaXqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ApXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitApXq(XqueyGrammarParser.ApXqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryXq(XqueyGrammarParser.BinaryXqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code VarXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarXq(XqueyGrammarParser.VarXqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LetXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLetXq(XqueyGrammarParser.LetXqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ForXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForXq(XqueyGrammarParser.ForXqContext ctx);
	/**
	 * Visit a parse tree produced by the {@code TagXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTagXq(XqueyGrammarParser.TagXqContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#forClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForClause(XqueyGrammarParser.ForClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#letClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLetClause(XqueyGrammarParser.LetClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#whereClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhereClause(XqueyGrammarParser.WhereClauseContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#returnClause}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnClause(XqueyGrammarParser.ReturnClauseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EqCond2}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEqCond2(XqueyGrammarParser.EqCond2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code CompoundCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompoundCond(XqueyGrammarParser.CompoundCondContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EqCond1}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEqCond1(XqueyGrammarParser.EqCond1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code SatCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSatCond(XqueyGrammarParser.SatCondContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EmptyCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEmptyCond(XqueyGrammarParser.EmptyCondContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NegCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegCond(XqueyGrammarParser.NegCondContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ParaCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParaCond(XqueyGrammarParser.ParaCondContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IsCond1}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIsCond1(XqueyGrammarParser.IsCond1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code IsCond2}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIsCond2(XqueyGrammarParser.IsCond2Context ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#satisfy}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSatisfy(XqueyGrammarParser.SatisfyContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#startTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStartTag(XqueyGrammarParser.StartTagContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#endTag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndTag(XqueyGrammarParser.EndTagContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#ap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAp(XqueyGrammarParser.ApContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp3}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp3(XqueyGrammarParser.UnaryRp3Context ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryRp1}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryRp1(XqueyGrammarParser.BinaryRp1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp4}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp4(XqueyGrammarParser.UnaryRp4Context ctx);
	/**
	 * Visit a parse tree produced by the {@code ParaRp}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParaRp(XqueyGrammarParser.ParaRpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryRp2}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryRp2(XqueyGrammarParser.BinaryRp2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp1}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp1(XqueyGrammarParser.UnaryRp1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp2}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp2(XqueyGrammarParser.UnaryRp2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFilterRp(XqueyGrammarParser.FilterRpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp5}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp5(XqueyGrammarParser.UnaryRp5Context ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp6}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp6(XqueyGrammarParser.UnaryRp6Context ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryFt1}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryFt1(XqueyGrammarParser.BinaryFt1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryFt2}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryFt2(XqueyGrammarParser.BinaryFt2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code ParaFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParaFt(XqueyGrammarParser.ParaFtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NegFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegFt(XqueyGrammarParser.NegFtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CompoundFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompoundFt(XqueyGrammarParser.CompoundFtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryFt(XqueyGrammarParser.UnaryFtContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#pathOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPathOp(XqueyGrammarParser.PathOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#docName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDocName(XqueyGrammarParser.DocNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#fileName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFileName(XqueyGrammarParser.FileNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#tagName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTagName(XqueyGrammarParser.TagNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#attName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttName(XqueyGrammarParser.AttNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#compOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompOp(XqueyGrammarParser.CompOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link XqueyGrammarParser#stringCondition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringCondition(XqueyGrammarParser.StringConditionContext ctx);
}
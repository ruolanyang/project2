// Generated from /Users/yiling/Desktop/2024 winter/232B/Project1/src/main/java/grammar/XpathGrammar.g4 by ANTLR 4.13.1
package grammar;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link XpathGrammarParser}.
 */
public interface XpathGrammarListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link XpathGrammarParser#ap}.
	 * @param ctx the parse tree
	 */
	void enterAp(XpathGrammarParser.ApContext ctx);
	/**
	 * Exit a parse tree produced by {@link XpathGrammarParser#ap}.
	 * @param ctx the parse tree
	 */
	void exitAp(XpathGrammarParser.ApContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp3}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp3(XpathGrammarParser.UnaryRp3Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp3}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp3(XpathGrammarParser.UnaryRp3Context ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryRp1}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterBinaryRp1(XpathGrammarParser.BinaryRp1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryRp1}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitBinaryRp1(XpathGrammarParser.BinaryRp1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp4}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp4(XpathGrammarParser.UnaryRp4Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp4}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp4(XpathGrammarParser.UnaryRp4Context ctx);
	/**
	 * Enter a parse tree produced by the {@code ParaRp}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterParaRp(XpathGrammarParser.ParaRpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParaRp}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitParaRp(XpathGrammarParser.ParaRpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryRp2}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterBinaryRp2(XpathGrammarParser.BinaryRp2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryRp2}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitBinaryRp2(XpathGrammarParser.BinaryRp2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp1}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp1(XpathGrammarParser.UnaryRp1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp1}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp1(XpathGrammarParser.UnaryRp1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp2}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp2(XpathGrammarParser.UnaryRp2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp2}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp2(XpathGrammarParser.UnaryRp2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterFilterRp(XpathGrammarParser.FilterRpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitFilterRp(XpathGrammarParser.FilterRpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp5}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp5(XpathGrammarParser.UnaryRp5Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp5}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp5(XpathGrammarParser.UnaryRp5Context ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp6}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp6(XpathGrammarParser.UnaryRp6Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp6}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp6(XpathGrammarParser.UnaryRp6Context ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryFt1}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterBinaryFt1(XpathGrammarParser.BinaryFt1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryFt1}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitBinaryFt1(XpathGrammarParser.BinaryFt1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryFt2}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterBinaryFt2(XpathGrammarParser.BinaryFt2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryFt2}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitBinaryFt2(XpathGrammarParser.BinaryFt2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code ParaFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterParaFt(XpathGrammarParser.ParaFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParaFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitParaFt(XpathGrammarParser.ParaFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NegFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterNegFt(XpathGrammarParser.NegFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NegFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitNegFt(XpathGrammarParser.NegFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CompoundFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterCompoundFt(XpathGrammarParser.CompoundFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CompoundFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitCompoundFt(XpathGrammarParser.CompoundFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterUnaryFt(XpathGrammarParser.UnaryFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitUnaryFt(XpathGrammarParser.UnaryFtContext ctx);
	/**
	 * Enter a parse tree produced by {@link XpathGrammarParser#pathOp}.
	 * @param ctx the parse tree
	 */
	void enterPathOp(XpathGrammarParser.PathOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link XpathGrammarParser#pathOp}.
	 * @param ctx the parse tree
	 */
	void exitPathOp(XpathGrammarParser.PathOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link XpathGrammarParser#docName}.
	 * @param ctx the parse tree
	 */
	void enterDocName(XpathGrammarParser.DocNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XpathGrammarParser#docName}.
	 * @param ctx the parse tree
	 */
	void exitDocName(XpathGrammarParser.DocNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XpathGrammarParser#fileName}.
	 * @param ctx the parse tree
	 */
	void enterFileName(XpathGrammarParser.FileNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XpathGrammarParser#fileName}.
	 * @param ctx the parse tree
	 */
	void exitFileName(XpathGrammarParser.FileNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XpathGrammarParser#tagName}.
	 * @param ctx the parse tree
	 */
	void enterTagName(XpathGrammarParser.TagNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XpathGrammarParser#tagName}.
	 * @param ctx the parse tree
	 */
	void exitTagName(XpathGrammarParser.TagNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XpathGrammarParser#attName}.
	 * @param ctx the parse tree
	 */
	void enterAttName(XpathGrammarParser.AttNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XpathGrammarParser#attName}.
	 * @param ctx the parse tree
	 */
	void exitAttName(XpathGrammarParser.AttNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XpathGrammarParser#compOp}.
	 * @param ctx the parse tree
	 */
	void enterCompOp(XpathGrammarParser.CompOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link XpathGrammarParser#compOp}.
	 * @param ctx the parse tree
	 */
	void exitCompOp(XpathGrammarParser.CompOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link XpathGrammarParser#stringCondition}.
	 * @param ctx the parse tree
	 */
	void enterStringCondition(XpathGrammarParser.StringConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link XpathGrammarParser#stringCondition}.
	 * @param ctx the parse tree
	 */
	void exitStringCondition(XpathGrammarParser.StringConditionContext ctx);
}